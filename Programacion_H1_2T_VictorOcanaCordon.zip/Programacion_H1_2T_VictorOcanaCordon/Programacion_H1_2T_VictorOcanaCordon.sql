drop database if exists Usuariosdb;
CREATE DATABASE Usuariosdb;
USE Usuariosdb;
drop table if exists Usuarios;
CREATE TABLE Usuarios(
    IdUsuario INT AUTO_INCREMENT PRIMARY KEY,  
    Nombre VARCHAR(255),                      
    Apellido VARCHAR(255) ,                     
    Edad 	numeric, 
    Email varchar(250) unique,
    Plan VARCHAR (50),
    Pack_deporte  boolean default 0,
    Pack_cine boolean default 0,
    Pack_infantil boolean default 0,
    Suscripcion  enum('Mensual','Anual'),
    precio_total DECIMAL(10,2)
    );


select * from Usuarios; 	
delete from Usuarios where IdUsuario=3;
DESCRIBE Usuarios;



