<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Usuario</title>
    <style>
        .nav {
            background-color: #99ccff;
            padding: 10px 20px;
            display: flex;
            justify-content: center;
            gap: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: black;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .nav-link:hover {
            background-color: #0066cc;
            color: white;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dee2e6;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
            color: #495057;
        }
        .container {
            margin-top: 30px;
        }
        .form-section {
            margin-top: 15px;
        }
        .form-section input,
        .form-section select {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <nav class="nav">
        <a class="nav-link" href="Altausuario.php">Dar de Alta</a>
        <a class="nav-link" href="Actualizarusuario.php">Actualizar Usuario</a>
        <a class="nav-link" href="Eliminarusuario.php">Eliminar Usuario</a>
        <a class="nav-link" href="MostrarUsuario.php">Ver Usuarios</a>
    </nav>

    <div class="container">
        <form method="POST" class="form-section">
            <h1>Buscar Usuario</h1>
            <div class="mb-3">
                <label for="email" class="form-label"><b>Email:</b></label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <button type="submit" name="buscar" class="btn btn-primary">Buscar</button>
        </form>

        <?php
        include './conexion.php';

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["buscar"])) {
            $email = $_POST["email"];
            $conexion = new mysqli("127.0.0.1", "root", "campusfp", "Usuariosdb");

            if ($conexion->connect_error) {
                die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
            }

            $sql = "SELECT * FROM Usuarios WHERE Email = '$email'";
            $resultado = $conexion->query($sql);

            if ($resultado->num_rows > 0) {
                $row = $resultado->fetch_assoc();
          
                echo "<h2>El Usuario tiene contratado:</h2>";
                echo "<table class='table table-bordered'>
                        <tr><th>Nombre</th><td>{$row['Nombre']}</td></tr>
                        <tr><th>Apellido</th><td>{$row['Apellido']}</td></tr>
                        <tr><th>Edad</th><td>{$row['Edad']}</td></tr>
                        <tr><th>Email</th><td>{$row['Email']}</td></tr>
                        <tr><th>Plan</th><td>{$row['Plan']}</td></tr>
                        <tr><th>Pack Deporte</th><td>" . ($row['Pack_deporte'] ? 'Sí' : 'No') . "</td></tr>
                        <tr><th>Pack Cine</th><td>" . ($row['Pack_cine'] ? 'Sí' : 'No') . "</td></tr>
                        <tr><th>Pack Infantil</th><td>" . ($row['Pack_infantil'] ? 'Sí' : 'No') . "</td></tr>
                        <tr><th>Suscripción</th><td>" . ($row['Suscripcion'] ) . "</td></tr>
                        <tr><th>Precio Total (€)</th><td>" . number_format($row['precio_total'], 2) . "€</td></tr>
                    </table>";                       

                echo "<h2>Actualizar Datos</h2>
                <form method='POST' class='form-section'>
                    <input type='hidden' name='email' value='{$email}'>
                    <div class='mb-3'>
                        <label for='Plan' class='form-label'><b>Nuevo Plan:</b></label>
                        <select name='Plan' class='form-select' required>
                            <option value='Básico' " . ($row['Plan'] == 'Básico' ? 'selected' : '') . ">Básico</option>
                            <option value='Estandar' " . ($row['Plan'] == 'Estandar' ? 'selected' : '') . ">Estándar</option>
                            <option value='Premium' " . ($row['Plan'] == 'Premium' ? 'selected' : '') . ">Premium</option>
                        </select>
                    </div>
                    <div class='mb-3'>
                        <b>Paquetes:</b><br>
                        <input type='checkbox' name='Pack_deporte' value='1' " . ($row['Pack_deporte'] ? 'checked' : '') . "> Deporte
                        <input type='checkbox' name='Pack_cine' value='1' " . ($row['Pack_cine'] ? 'checked' : '') . "> Cine
                        <input type='checkbox' name='Pack_infantil' value='1' " . ($row['Pack_infantil'] ? 'checked' : '') . "> Infantil
                    </div>
                    <button type='submit' name='actualizar' class='btn btn-success'>Actualizar</button>
                </form>";
            } else {
                echo "<h2>No se encontró un usuario con ese email.</h2>";
            }

            $conexion->close();
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["actualizar"])) {
            $conexion = new mysqli("127.0.0.1", "root", "campusfp", "Usuariosdb");

            if ($conexion->connect_error) {
                die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
            }

            $email = $_POST["email"];
            $Plan = $_POST["Plan"];
            $Pack_deporte = isset($_POST["Pack_deporte"]) ? 1 : 0;
            $Pack_cine = isset($_POST["Pack_cine"]) ? 1 : 0;
            $Pack_infantil = isset($_POST["Pack_infantil"]) ? 1 : 0;

            $precios_planes = ["Básico" => 9.99, "Estandar" => 13.99, "Premium" => 17.99];
            $precios_paquetes = ["Deporte" => 6.99, "Cine" => 7.99, "Infantil" => 4.99];

            $precio_plan_base = $precios_planes[$Plan];
            $precio_total_paquetes = 
                ($Pack_deporte * $precios_paquetes["Deporte"]) + 
                ($Pack_cine * $precios_paquetes["Cine"]) + 
                ($Pack_infantil * $precios_paquetes["Infantil"]);

            $precio_total = $precio_plan_base + $precio_total_paquetes;

            $sql = "UPDATE Usuarios SET 
                        Plan = '$Plan', 
                        Pack_deporte = '$Pack_deporte', 
                        Pack_cine = '$Pack_cine', 
                        Pack_infantil = '$Pack_infantil',
                        precio_total = '$precio_total'
                    WHERE Email = '$email'";

            if ($conexion->query($sql)) {
                echo "<h2 class='text-success'>Usuario actualizado correctamente.</h2>";
            } else {
                echo "<h2 class='text-danger'>Error al actualizar: " . $conexion->error . "</h2>";
            }

            $conexion->close();
        }
        ?>
    </div>
</body>
</html>
