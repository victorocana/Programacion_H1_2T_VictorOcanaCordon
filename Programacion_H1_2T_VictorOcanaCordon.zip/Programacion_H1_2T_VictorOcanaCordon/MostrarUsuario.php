<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<!DOCTYPE html>
<html>
<head>
<title>Mostrar Usuario</title>
<style>
    /* Estilos generales para la tabla */
    table {
        width: 100%;
        border-collapse: collapse; 
    }

    th, td {
        border: 1px solid #000;
        padding: 5px;
        text-align: center;
    }

    th {
        background-color: #d3d3d3; 
        font-weight: bold; 
        color: black; 
    }
        .nav {
            background-color: #99ccff;
            padding: 10px 20px;
            display: flex;
            justify-content: center;
            gap: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: black;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .nav-link:hover {
            background-color: #0066cc;
            color: white;
        }

    </style>
<nav class="nav">
  <a class="nav-link active" aria-current="page" href="Altausuario.php">Dar de Alta</a>
  <a class="nav-link" href="Actualizarusuario.php">Actualizar Usuario</a>
  <a class="nav-link" href="Eliminarusuario.php">Eliminar Usuario</a>
  <a class="nav-link" href="MostrarUsuario.php">Ver Usuarios</a>
</nav>

<body>
<?php
//Conectamos con la base de datos
include_once './conexion.php';
$email= null;
$conexion = new mysqli("127.0.0.1", "root", "campusfp", "Usuariosdb");

if ($conexion->connect_error) {
    die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
}

$sql = "SELECT * FROM Usuarios";
$resultado = $conexion->query($sql, MYSQLI_USE_RESULT);

if ($resultado) {
?>
   
    <table>
        <thead>
            <tr> 
                <th>IdUsuario</th>
                <th>Nombre</th> 
                <th>Apellido</th>
                <th>Edad</th> 
                <th>Email</th> 
                <th>Plan</th>
                <th>Pack_deporte</th>
                <th>Pack_cine</th>
                <th>Pack_infantil</th>
                <th>Suscripción</th>
                <th>Precio(€)</th>
                <th>CAMBIO</th>
            </tr>
        </thead>
        <tbody>
            
        <?php
        $row = $resultado->fetch_assoc();
        while ($row) {
            echo "<tr>";
            echo "<td>" . $row['IdUsuario'] . "</td>";
            echo "<td>" . $row['Nombre'] . "</td>";
            echo "<td>" . $row['Apellido'] . "</td>";
            echo "<td>" . $row['Edad'] . "</td>";
            echo "<td>" . $row['Email'] . "</td>";
            echo "<td>" . $row['Plan'] . "</td>";
            echo "<td>" . ($row['Pack_deporte'] ? 'Sí' : 'No') . "</td>";
            echo "<td>" . ($row['Pack_cine'] ? 'Sí' : 'No') . "</td>";
            echo "<td>" . ($row['Pack_infantil'] ? 'Sí' : 'No') . "</td>";
            echo "<td>" . $row['Suscripcion'] . "</td>";
            echo "<td>" . number_format($row['precio_total'], 2) . "€</td>";
            echo "<td>
                

                <!-- Los botones para eliminar y actualizar -->
                
                <form action='eliminarusuario.php' method='POST' style='display:inline;'>
                    <input type='hidden' name='IdUsuario' value='" . $row['IdUsuario'] . "'>
                    <button type='submit'>Eliminar</button>
                </form>
                <form action='Actualizarusuario.php' method='GET' style='display:inline;'>
                    <input type='hidden' name='IdUsuario' value='" . $row['IdUsuario'] . "'>
                    <button type='submit'>Actualizar</button>
                </form>
            </td>";
            echo "</tr>";
            $row = $resultado->fetch_assoc();
        }
        ?>
        </tbody>
    </table>
    <br><br>
    <form action="" method="POST"> 
        Correo electrónico a buscar: 
        <input type="text" name="emailbuscar" required>
        <input type="submit" value="Buscar">
        <br>
    </form>
<?php
    include './conexion.php';
    $emailbuscar = '';
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["emailbuscar"])) {
    $emailbuscar = trim($_POST["emailbuscar"]);

    $sql = "SELECT * FROM usuarios WHERE Email='$emailbuscar'";
    $resultado = $conexion->query($sql);

    if ($resultado && $resultado->num_rows > 0) {
        $row = $resultado->fetch_assoc();
        $Nombre = $row['Nombre'];
        $Apellido = $row['Apellido'];
        $Plan = $row['Plan'];
        $Pack_deporte = $row['Pack_deporte'];
        $Pack_cine = $row['Pack_cine'];
        $Pack_infantil = $row['Pack_infantil'];
        $precio_total = $row['precio_total'];
        } 

       else {
        echo "<h3>No se encontró un usuario con ese correo.</h3>";
        }
        
        $precios_plan_base = ["Básico" => 9.99, "Estandar" => 13.99, "Premium" => 17.99];
        $precio_plan_base = $precios_plan_base[$Plan];

        // Determinar precios de paquetes opcionales
        $precio_paquete_deporte = ($Pack_deporte == 1) ? 6.99 : "Sin contrato";
        $precio_paquete_cine = ($Pack_cine == 1) ? 7.99 : "Sin contrato";
        $precio_paquete_infantil = ($Pack_infantil == 1) ? 4.99 : "Sin contrato";
        }
    
        // Mostramos el precio desglosado de cada usuairio
        echo "<b>El desglose de el usuario $Nombre $Apellido con correo $emailbuscar</b>";
        echo "<p>";
        echo "<ul>";
        echo "<li>Plan Base: $Plan con un coste de $precio_plan_base €</li>";
        echo "<li>Paquete Deporte: $Pack_deporte con coste $precio_paquete_deporte €</li>";
        echo "<li>Paquete Cine: $Pack_cine con coste $precio_paquete_cine €</li>";
        echo "<li>Paquete Infantil: $Pack_infantil con coste $precio_paquete_infantil €</li>";
        echo "</ul>";
        echo "</p>";
        echo "<b>Precio Total en €: $precio_total</b>";
    } else {
    echo "Error al obtener el listado de usuarios";
}


?>
    
<?php
//cerramos conexión
    $resultado->close();

$conexion->close();
?>
</body>
</html>