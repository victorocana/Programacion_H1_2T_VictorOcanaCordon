<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Metadatos de la página, como la codificación y la configuración de la vista -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta Usuario</title>
</head>

<style>
    /* Estilos generales para la tabla */
    table {
        width: 100%;
        border-collapse: collapse; 
    }

    th, td {
        border: 1px solid #000;
        padding: 5px;
        text-align: center;
    }

    th {
        background-color: #d3d3d3; 
        font-weight: bold; 
        color: black; 
    }
        .nav {
            background-color: #99ccff;
            padding: 10px 20px;
            display: flex;
            justify-content: center;
            gap: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: black;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .nav-link:hover {
            background-color: #0066cc;
            color: white;
        }

    </style>
</head>
<body>
    </style>
    <!-- Barra de navegación -->
<nav class="nav">
  <a class="nav-link active" aria-current="page" href="Altausuario.php">Dar de Alta </a>
  <a class="nav-link" href="Actualizarusuario.php">Actualizar Usuario</a>
  <a class="nav-link" href="Eliminarusuario.php">Eliminar Usuario</a>
  <a class="nav-link" href="MostrarUsuario.php">Ver Usuarios</a>
</nav>

    <!-- Pedimos los datos del usuario. -->
<body>
    <br>
<form action="" method="POST">
        <b>Nombre:</b> <input type="text" name="Nombre" required>
        <br><br>
        <b>Apellido:</b> <input type="text" name="Apellido" required>
        <br><br>
        <b>Edad: </b><input type="number" name="edad" min="0" max="120" required>
        <br><br>
        <b>Email: </b> <input type="email" name="email"  required>
        <br><br>
        <b>Plan Base:</b>
        <select name="Plan" id="Plan" required>
            <option value="" disabled selected>Selecciona un Plan Base</option>
            <option value="Básico">Básico</option>
            <option value="Estandar">Estándar</option>
            <option value="Premium">Premium</option>
        </select>
        <br><br>
        <!-- Selecciona los paquetes -->
        <b>Paquetes:</b>
        <input type="checkbox" name="Pack_deporte" value="1"> Deporte
        <input type="checkbox" name="Pack_cine" value="1"> Cine
        <input type="checkbox" name="Pack_infantil" value="1"> Infantil
        <br><br>
        <!-- Selecciona la suscripción (mensual o anual) -->
        <b>Suscripción: </b><Select name="Suscripcion">
            <OPTION VALUE="Mensual">Mensual
            <OPTION VALUE="Anual">Anual
        </select>
        <br><br>
 <!-- Botón para enviar el formulario -->
        <button type="submit">Agregar</button>

</form>
    <!-- Tabla con dichas restricciones a los planes -->
    <table>
        <thead>
            <tr>
                <th>Tipo de Plan</th>
                <th>Precio Mensual (€)</th>
            </tr>
        </thead>
        <tbody>
            <tr><td>Plan Básico (1 dispositivo)</td><td>9,99€</td></tr>
            <tr><td>Plan Estándar (2 dispositivos)</td><td>13,99€</td></tr>
            <tr><td>Plan Premium (4 dispositivos)</td><td>17,99€</td></tr>
        </tbody>
    </table>

    <!-- Tabla con dichas restricciones en los packs -->
    <table>
        <thead>
            <tr>
                <th>Pack</th>
                <th>Precio Mensual (€)</th>
            </tr>
        </thead>
        <tbody>
            <tr><td>Deporte</td><td>6,99€</td></tr>
            <tr><td>Cine</td><td>7,99€</td></tr>
            <tr><td>Infantil</td><td>4,99€</td></tr>
        </tbody>
    </table>


</form>
    
<?php
// Conectar con la base de datos
include './conexion.php';

if ($conexion->connect_error) {
    die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Nombre = $_REQUEST["Nombre"];
    $Apellido = $_REQUEST["Apellido"];
    $Edad = $_REQUEST["edad"];
    $email = $_REQUEST ["email"];
    $Plan = $_REQUEST["Plan"];
    $Pack_deporte = isset($_REQUEST["Pack_deporte"]) ? 1 : 0;
    $Pack_cine = isset($_REQUEST["Pack_cine"]) ? 1 : 0;
    $Pack_infantil = isset($_REQUEST["Pack_infantil"]) ? 1 : 0;
    $Suscripcion = $_REQUEST["Suscripcion"];

    // Restricción 1: Si la edad es menor de 18, solo puede seleccionar el Pack Infantil
    if ($Edad < 18 && ($Pack_deporte || $Pack_cine)) {
        echo "<h2>Error: Los usuarios menores de 18 años solo pueden contratar el Pack Infantil.</h2>";
        exit();
    }

    // Restricción 2: Si el Plan es Básico, solo puede seleccionar un paquete adicional
    $total_packs = $Pack_deporte + $Pack_cine + $Pack_infantil;
    if ($Plan === 'Básico' && $total_packs > 1) {
        echo "<h2>Error: Los usuarios con el Plan Básico solo pueden contratar un paquete adicional.</h2>";
        exit();
    }

    // Restricción 3: Si el Pack Deporte está seleccionado, la suscripción debe ser anual
    if ($Pack_deporte && $Suscripcion !== 'Anual') {
        echo "<h2>Error: Los usuarios con el Pack Deporte deben seleccionar una suscripción Anual.</h2>";
        exit();
    }

    // Verificar si el email ya existe
    $email_check_query = "SELECT * FROM Usuarios WHERE Email = '$email'";
    $result = $conexion->query($email_check_query);

    if ($result->num_rows > 0) {
        echo "<h2>Error: El email $email ya está registrado.</h2>";
        exit();  // Detener el proceso si el email ya existe
    }

    // Calculamos los precios
    $precios_planes = ["Básico" => 9.99, "Estandar" => 13.99, "Premium" => 17.99];
    $precios_paquetes = ["Deporte" => 6.99, "Cine" => 7.99, "Infantil" => 4.99];

    $precio_plan_base = $precios_planes[$Plan];
    $precio_total_paquetes = 
        ($Pack_deporte * $precios_paquetes["Deporte"]) + 
        ($Pack_cine * $precios_paquetes["Cine"]) + 
        ($Pack_infantil * $precios_paquetes["Infantil"]);

    $precio_total = $precio_plan_base + $precio_total_paquetes;

    // Insertar datos en la base de datos
    $sql = "INSERT INTO Usuarios (Nombre, Apellido, Edad, Email, Plan, Pack_deporte, Pack_cine, Pack_infantil, Suscripcion, precio_total)
            VALUES ('$Nombre', '$Apellido', '$Edad', '$email', '$Plan', '$Pack_deporte', '$Pack_cine', '$Pack_infantil', '$Suscripcion', '$precio_total');";

    if ($conexion->query($sql)) {
        echo "<h2>Se ha dado de alta al Usuario: $Nombre $Apellido con $Edad años, Plan $Plan , Paquetes $Pack_deporte $Pack_cine $Pack_infantil y la Suscripción $Suscripcion.</h2>";
    } else {
        echo "<h2>Error al registrar el usuario: " . $conexion->error . "</h2>";
    }
}

$conexion->close();
?>


    
</body>
</html>
