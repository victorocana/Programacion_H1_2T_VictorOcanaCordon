<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN6jIeHz" crossorigin="anonymous"></script>

<!DOCTYPE html>
<html>
<head>
<title>Eliminar Usuario</title>
<style>
    .container {
        margin-top: 50px;
        max-width: 600px;
    }
        .nav {
            background-color: #99ccff;
            padding: 10px 20px;
            display: flex;
            justify-content: center;
            gap: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: black;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .nav-link:hover {
            background-color: #0066cc;
            color: white;
        }essage {
        margin-top: 20px;
        font-size: 18px;
        font-weight: bold;
    }
    .success {
        color: white;
        background-color: green;
    }
    .error {
        color: white;
        background-color: red;
    }
</style>
</head>
<body>
<nav class="nav">
  <a class="nav-link active" aria-current="page" href="Altausuario.php">Dar de Alta</a>
  <a class="nav-link" href="Actualizarusuario.php">Actualizar Usuario</a>
  <a class="nav-link" href="Eliminarusuario.php">Eliminar Usuario</a>
  <a class="nav-link" href="MostrarUsuario.php">Ver Usuarios</a>
</nav>

    
<div class="container">
    <h1>Eliminar Usuario</h1>
    <form action="" method="POST">
        <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico:</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-danger">Eliminar Usuario</button>
    </form>

    <?php
    // Conexión a la base de datos
    include_once './conexion.php';
    $conexion = new mysqli("127.0.0.1", "root", "campusfp", "Usuariosdb");

    if ($conexion->connect_error) {
        echo '<p class="message error">Error de conexión: ' . $conexion->connect_error . '</p>';
        exit();
    }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email'])) {
        // Obtener el email del formulario y sanitizarlo
        $email = $conexion->real_escape_string($_POST['email']);

        // Consulta para eliminar el usuario
        $sql = "DELETE FROM Usuarios WHERE email = '$email'";
        if ($conexion->query($sql) === TRUE) {
            if ($conexion->affected_rows > 0) {
                echo '<p class="message success">Usuario con correo <b>' . htmlspecialchars($email) . '</b> eliminado correctamente.</p>';
            } else {
                echo '<p class="message error">No se encontró un usuario con ese correo.</p>';
            }
        } else {
            echo '<p class="message error">Error al eliminar el usuario: ' . $conexion->error . '</p>';
        }
    } else {
        echo '<p class="message error">El campo "email" es obligatorio.</p>';
    }


        // Error al eliminar ese usuario
        }else {
            echo '<p class="message error">Debe introducir un correo electrónico: ' . $conexion->error . '</p>';
        }
   

    $conexion->close();
    ?>
</div>
</body>
</html>
